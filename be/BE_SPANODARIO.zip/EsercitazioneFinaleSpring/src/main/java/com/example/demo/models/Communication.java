package com.example.demo.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="SPANO_COMMUNICATION")
public class Communication {
    @Id
    @GeneratedValue
    private Long id;
    @ManyToOne
    @JoinColumn(name="idCandidate", referencedColumnName = "id")
   private Candidate idCandidate;
    @ManyToOne
    @JoinColumn(name="idJobOffer", referencedColumnName = "id")
   private JobOffer idJobOffer;
   private String description;
   private LocalDate data;

    public Communication(Candidate idCandidate, JobOffer idJobOffer, String description, LocalDate data) {
        this.idCandidate = idCandidate;
        this.idJobOffer = idJobOffer;
        this.description = description;
        this.data = data;
    }
}
