package com.example.demo.services;

import com.example.demo.models.JobOffer;

import java.util.List;

public interface JobOfferService {
    List<JobOffer>getALlJobOffer();
    JobOffer getJobOffer(Long id);
    void addJobOffer(JobOffer jobOffer);
    void removeJobOffer(Long id);
    void updateJobOffer(JobOffer jobOffer, Long id);
    List<JobOffer> findByAgency(String agency);
}
