package com.example.demo.services;

import com.example.demo.models.Communication;
import com.example.demo.repositories.CommunicationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommunicationServiceDB implements  CommunicationService{
    @Autowired
    private CommunicationRepository communicationRepository;

    @Override
    public List<Communication> getAllCommunications() {
        return this.communicationRepository.findAll();
    }

    @Override
    public Communication getCommunication(Long id) {
        Optional<Communication>communication=this.communicationRepository.findById(id);
        return communication.orElse(null);
    }

    @Override
    public void addCommunication(Communication communication) {
        this.communicationRepository.save(communication);
    }

    @Override
    public void removeCommunication(Long id) {
        this.communicationRepository.deleteById(id);
    }

    @Override
    public void updateCommunication(Communication communication, Long id) {
        Optional<Communication>communication1=this.communicationRepository.findById(id);
        if(communication1.isPresent()){
            Communication communicationToUpdate=new Communication();
            communicationToUpdate.setId(id);
            communicationToUpdate.setData(communication.getData());
            communicationToUpdate.setIdCandidate(communication.getIdCandidate());
            communicationToUpdate.setDescription(communication.getDescription());
            communicationToUpdate.setIdJobOffer(communication.getIdJobOffer());
            this.communicationRepository.save(communicationToUpdate);
        }
    }
}
