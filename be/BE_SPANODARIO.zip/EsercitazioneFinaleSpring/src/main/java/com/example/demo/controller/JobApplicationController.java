package com.example.demo.controller;

import com.example.demo.models.JobApplication;
import com.example.demo.services.JobApplicationDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class JobApplicationController {
    @Autowired
    private JobApplicationDB jobApplicationDB;

    @GetMapping(value="/jobApplications")
    public List<JobApplication>getAllJobApplications(){
        return this.jobApplicationDB.getAllJobApplications();
    }
    @GetMapping(value="/getJobApplication")
    public JobApplication getJobApplication(@RequestParam Long id){
        return this.jobApplicationDB.getJobApplication(id);
    }
    @PostMapping(value="/addJobApplication")
    public void addJobApplication(@RequestBody JobApplication jobApplication){
        this.jobApplicationDB.addJobApplication(jobApplication);
    }
    @DeleteMapping(value="/deleteJobApplication")
    public void removeJobApplication(@RequestParam Long id){
        this.jobApplicationDB.removeJobApplication(id);
    }
    @PutMapping(value="/updateJobApplication")
    public void updateJobApplication(@RequestBody JobApplication jobApplication, @RequestParam Long id){
        this.jobApplicationDB.updateJobApplication(jobApplication, id);
    }
}
