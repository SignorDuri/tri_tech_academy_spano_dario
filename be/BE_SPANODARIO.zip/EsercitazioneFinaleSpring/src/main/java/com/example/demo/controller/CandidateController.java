package com.example.demo.controller;
import com.example.demo.models.Candidate;
import com.example.demo.services.CandidateServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CandidateController {
    @Autowired
    private CandidateServiceDB candidateServiceDB;
    @GetMapping(value="/candidates")
    public List<Candidate> getAllCandidates(){
        return this.candidateServiceDB.getAllCandidates();
    }
    @GetMapping(value="/getCandidate")
    public Candidate getCandidate(@RequestParam Long id){
        return this.candidateServiceDB.getCandidate(id);
    }
    @PostMapping(value="/addCandidate")
        public void addCandidate(@RequestBody Candidate candidate){
            this.candidateServiceDB.addCandidate(candidate);
    }
    @PutMapping(value="/updateCandidate")
    public void updateCandidate(@RequestParam Long id, @RequestBody Candidate candidate){
        this.candidateServiceDB.updateCandidate(candidate, id);
    }
    @DeleteMapping(value="/deleteCandidate")
    public void deleteCandidate(@RequestParam Long id){
        this.candidateServiceDB.removeCandidate(id);
    }
    @GetMapping(value="/findCandidate")
    public Candidate findCandidate(@RequestParam String email){
        return this.candidateServiceDB.findByEmail(email);
    }

  @GetMapping(value="/candidates/searchByNameAndSurname")
    public List<Candidate> findByCandidate(@RequestParam String firstName, @RequestParam String lastName){
        return this.candidateServiceDB.findByCandidate(firstName, lastName);
    }

}



