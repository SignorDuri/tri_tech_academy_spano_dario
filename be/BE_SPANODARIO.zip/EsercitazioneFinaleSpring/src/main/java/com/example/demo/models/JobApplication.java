package com.example.demo.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="SPANO_JOBAPPLICATION")
public class JobApplication {
    @Id
    @GeneratedValue
    private Long id;
    @ManyToOne
    @JoinColumn(name="idCandidate", referencedColumnName = "id")
    private Candidate idCandidate;
    private String description;
    private LocalDate candidatureDate;
    private String status;

    public JobApplication(Candidate idCandidate, String description, LocalDate candidatureDate, String status) {
        this.idCandidate = idCandidate;
        this.description = description;
        this.candidatureDate=candidatureDate;
        this.status=status;
    }
}
