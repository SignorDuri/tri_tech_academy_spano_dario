package com.example.demo.controller;
import com.example.demo.models.JobOffer;
import com.example.demo.services.JobOfferDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class JobOfferController {
    @Autowired
    private JobOfferDB jobOfferDB;
    @GetMapping(value="/JobOffers")
    public List<JobOffer>getAllJobOffers(){
        return this.jobOfferDB.getALlJobOffer();
    }
    @GetMapping(value="/getJobOffer")
    public JobOffer getJobOffer(@RequestParam  Long id){
        return this.jobOfferDB.getJobOffer(id);
    }
    @PostMapping(value="/addJobOffer")
    public void addJobOffer(@RequestBody JobOffer jobOffer){
        this.jobOfferDB.addJobOffer(jobOffer);
    }
    @DeleteMapping(value="/deleteJobOffer")
    public void removeJobOffer(@RequestParam Long id){
        this.jobOfferDB.removeJobOffer(id);
    }
    @PutMapping(value="/updateJobOffer")
    public void updateJobOffer(@RequestBody JobOffer jobOffer, @RequestParam Long id){
        this.jobOfferDB.updateJobOffer(jobOffer, id);
    }
    @GetMapping(value="/jobOffers/findByAgency")
    public List<JobOffer> findByAgency(@RequestParam String agency){
        return this.jobOfferDB.findByAgency(agency);
    }
}
