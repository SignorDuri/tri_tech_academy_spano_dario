package com.example.demo.services;

import com.example.demo.models.JobOffer;
import com.example.demo.repositories.JobOfferRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobOfferDB implements  JobOfferService{
    @Autowired
    private JobOfferRepository jobOfferRepository;

    @Override
    public List<JobOffer> getALlJobOffer() {
        return this.jobOfferRepository.findAll();
    }

    @Override
    public JobOffer getJobOffer(Long id) {
        Optional<JobOffer>jobOffer=this.jobOfferRepository.findById(id);
        return  jobOffer.orElse(null);
    }

    @Override
    public void addJobOffer(JobOffer jobOffer) {
        this.jobOfferRepository.save(jobOffer);
    }

    @Override
    public void removeJobOffer(Long id) {
        this.jobOfferRepository.deleteById(id);
    }

    @Override
    public void updateJobOffer(JobOffer jobOffer, Long id) {
        Optional<JobOffer>jobOffer1=this.jobOfferRepository.findById(id);
        if(jobOffer1.isPresent()){
            JobOffer jobOfferToUpdate=new JobOffer();
            jobOfferToUpdate.setId(id);
            jobOfferToUpdate.setJobType(jobOffer.getJobType());
            jobOfferToUpdate.setAddress(jobOffer.getAddress());
            jobOfferToUpdate.setStatus(jobOffer.getStatus());
            jobOfferToUpdate.setAgency(jobOffer.getAgency());
            this.jobOfferRepository.save(jobOfferToUpdate);
        }

    }
    public List<JobOffer> findByAgency(String agency){
        return this.jobOfferRepository.findByAgency(agency);
    }
}
