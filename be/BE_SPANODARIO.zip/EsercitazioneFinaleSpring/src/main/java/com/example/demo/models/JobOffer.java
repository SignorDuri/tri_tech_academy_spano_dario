package com.example.demo.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="SPANO_JOBOFFER")
public class JobOffer {
    @Id
    @GeneratedValue
    private Long id;
    private String agency;
    private String status;
    private String jobType;
    private String address;

    public JobOffer(String agency, String status, String jobType, String address) {
        this.agency = agency;
        this.status = status;
        this.jobType = jobType;
        this.address = address;
    }
}
