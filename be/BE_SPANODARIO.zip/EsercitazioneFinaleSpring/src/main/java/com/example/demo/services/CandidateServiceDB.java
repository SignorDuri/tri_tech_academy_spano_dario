package com.example.demo.services;
import com.example.demo.models.Candidate;
import com.example.demo.repositories.CandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class CandidateServiceDB implements CandidateService{
    @Autowired
    private CandidateRepository candidateRepository;

    @Override
    public List<Candidate> getAllCandidates() {
        return this.candidateRepository.findAll();
    }

    @Override
    public void addCandidate(Candidate candidate) {
        this.candidateRepository.save(candidate);
    }

    @Override
    public void removeCandidate(Long id) {
        this.candidateRepository.deleteById(id);
    }

    @Override
    public Candidate getCandidate(Long id) {
        Optional<Candidate> candidate=this.candidateRepository.findById(id);
        return candidate.orElse(null);
    }

    @Override
    public void updateCandidate(Candidate candidate, Long id) {
        Optional<Candidate> candidateOptional=this.candidateRepository.findById(id);
        if(candidateOptional.isPresent()){
            Candidate candidateToUpdate=new Candidate();
            candidateToUpdate.setId(id);
            candidateToUpdate.setAddress(candidate.getAddress());
            candidateToUpdate.setEmail(candidate.getEmail());
            candidateToUpdate.setTelephone(candidate.getTelephone());
            candidateToUpdate.setFirstName(candidate.getFirstName());
            candidateToUpdate.setBirthdayDate(candidate.getBirthdayDate());
            candidateToUpdate.setLastName(candidate.getLastName());
            this.candidateRepository.save(candidateToUpdate);
        }

    }

    @Override
    public Candidate findByEmail(String email) {
        Optional<Candidate> candidateOptional= this.candidateRepository.findByEmail(email);
        return candidateOptional.orElse(null);
    }

    @Override
    public List<Candidate> findByCandidate(String firstName, String lastName) {
        return this.candidateRepository.findByFirstNameAndLastName(firstName, lastName);
    }
}
