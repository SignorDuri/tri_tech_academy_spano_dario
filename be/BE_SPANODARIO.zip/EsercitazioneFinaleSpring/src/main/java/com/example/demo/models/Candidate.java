package com.example.demo.models;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="SPANO_CANDIDATE")
public class Candidate {
    @Id
    @GeneratedValue
    private Long id;
    private String firstName;
    private String lastName;
    private LocalDate birthdayDate;
    private String email;
    private String address;
    private String telephone;

    public Candidate(String firstName, String lastName, LocalDate birthdayDate, String email, String address, String telephone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthdayDate = birthdayDate;
        this.email = email;
        this.address = address;
        this.telephone = telephone;
    }
}
