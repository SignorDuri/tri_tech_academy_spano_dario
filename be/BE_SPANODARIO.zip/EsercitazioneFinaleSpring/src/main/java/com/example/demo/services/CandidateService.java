package com.example.demo.services;

import com.example.demo.models.Candidate;

import java.util.List;

public interface CandidateService {
    List<Candidate> getAllCandidates();

    void addCandidate(Candidate candidate);

    void removeCandidate(Long id);

    Candidate getCandidate(Long id);

    void updateCandidate(Candidate candidate, Long id);

    Candidate findByEmail(String email);
    List<Candidate> findByCandidate(String firstName, String lastName);
}
