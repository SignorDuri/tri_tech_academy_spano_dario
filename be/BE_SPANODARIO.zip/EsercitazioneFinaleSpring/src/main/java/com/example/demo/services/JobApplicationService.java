package com.example.demo.services;

import com.example.demo.models.JobApplication;

import java.util.List;

public interface JobApplicationService {
    List<JobApplication> getAllJobApplications();
     JobApplication getJobApplication(Long id);
     void addJobApplication(JobApplication jobApplication);
     void removeJobApplication(Long id);
     void updateJobApplication(JobApplication jobApplication, Long id);
}
