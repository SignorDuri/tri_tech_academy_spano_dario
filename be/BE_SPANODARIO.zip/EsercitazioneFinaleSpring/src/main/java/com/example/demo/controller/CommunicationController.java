package com.example.demo.controller;

import com.example.demo.models.Communication;
import com.example.demo.services.CommunicationServiceDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CommunicationController {
    @Autowired
    private CommunicationServiceDB communicationServiceDB;
    @GetMapping(value="/communications")
    public List<Communication> getAllCommunications(){
        return this.communicationServiceDB.getAllCommunications();
    }
    @GetMapping(value="/getCommunication")
    public Communication getCommunication(@RequestParam Long id){
        return this.communicationServiceDB.getCommunication(id);
    }
    @PostMapping("/addCommunication")
    public void addCommunication(@RequestBody Communication communication){
        this.communicationServiceDB.addCommunication(communication);
    }
    @DeleteMapping("/deleteCommunication")
    public void deleteMapping(@RequestParam Long id){
        this.communicationServiceDB.removeCommunication(id);
    }
    @PutMapping("/updateCommunication")
    public void updateCommunication(@RequestBody Communication communication, @RequestParam Long id){
        this.communicationServiceDB.updateCommunication(communication, id);
    }

}
