package com.example.demo.services;

import com.example.demo.models.Candidate;
import com.example.demo.models.JobApplication;
import com.example.demo.repositories.JobApplicationRepository;
import com.example.demo.services.utilities.EmailSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class JobApplicationDB implements JobApplicationService{
    @Autowired
    private JobApplicationRepository jobApplicationRepository;
    @Autowired
    private EmailSenderService emailSenderService;

    @Override
    public List<JobApplication> getAllJobApplications() {
        return this.jobApplicationRepository.findAll();
    }

    @Override
    public JobApplication getJobApplication(Long id) {
        Optional<JobApplication>jobApplication=this.jobApplicationRepository.findById(id);
        return jobApplication.orElse(null);
    }

    @Override
    public void addJobApplication(JobApplication jobApplication) {
        this.jobApplicationRepository.save(jobApplication);
        //this.emailSenderService.sendEmail(jobApplication.getIdCandidate().getEmail(), jobApplication.getIdCandidate().getFirstName());

    }

    @Override
    public void removeJobApplication(Long id) {
        this.jobApplicationRepository.deleteById(id);
    }

    @Override
    public void updateJobApplication(JobApplication jobApplication, Long id) {
        Optional<JobApplication>jobApplication1=this.jobApplicationRepository.findById(id);
        if(jobApplication1.isPresent()){
            JobApplication jobApplicationToUpdate=new JobApplication();
            jobApplicationToUpdate.setId(jobApplicationToUpdate.getId());
            jobApplicationToUpdate.setIdCandidate(jobApplication.getIdCandidate());
            jobApplicationToUpdate.setDescription(jobApplication.getDescription());
            jobApplicationToUpdate.setStatus("viewed");
            jobApplicationToUpdate.setCandidatureDate(jobApplication.getCandidatureDate());
            this.jobApplicationRepository.save(jobApplicationToUpdate);
        }
    }
}
