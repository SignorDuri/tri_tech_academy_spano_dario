package com.example.demo.services;

import com.example.demo.models.Communication;

import java.util.List;

public interface CommunicationService {
    List<Communication>getAllCommunications();
    Communication getCommunication(Long id);
    void addCommunication(Communication communication);
    void removeCommunication(Long id);
    void updateCommunication(Communication communication, Long id);
}
