import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ViewOffersComponent } from './view-offers/view-offers.component';
import { SendCandidatureComponent } from './send-candidature/send-candidature.component';
import { CreateJoobOfferComponent } from './create-job-offer/create-joob-offer.component';
import { ViewCandidateComponent } from './view-candidate/view-candidate.component';
import { HumanHomeComponent } from './human-home/human-home.component';
import { JobOffersDashboardComponent } from './job-offers-dashboard/job-offers-dashboard.component';



export const routes: Routes = [
    {path:'',component:HomeComponent},
    {path:'viewOffers', component:ViewOffersComponent},
    {path:'sendCandidature', component:SendCandidatureComponent},
    {path:'createJobOffer', component:CreateJoobOfferComponent},
    {path: 'viewCandidates', component:ViewCandidateComponent},
    {path: 'humanHome', component:HumanHomeComponent},
    {path: 'JobDash', component: JobOffersDashboardComponent},
];
