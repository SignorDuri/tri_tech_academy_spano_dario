import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HumanHomeComponent } from './human-home.component';

describe('HumanHomeComponent', () => {
  let component: HumanHomeComponent;
  let fixture: ComponentFixture<HumanHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HumanHomeComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(HumanHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
