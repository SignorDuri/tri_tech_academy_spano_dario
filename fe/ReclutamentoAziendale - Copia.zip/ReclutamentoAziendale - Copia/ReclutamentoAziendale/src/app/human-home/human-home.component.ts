import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-human-home',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './human-home.component.html',
  styleUrl: './human-home.component.css'
})
export class HumanHomeComponent {

}
