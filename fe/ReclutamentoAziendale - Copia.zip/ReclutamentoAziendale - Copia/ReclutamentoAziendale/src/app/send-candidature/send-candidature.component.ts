import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { candidate, candidature } from '../interfaces/Recruiting.interface';
import { RecruitingService } from '../Services/recruiting.service';

@Component({
  selector: 'app-send-candidature',
  standalone: true,
  imports: [RouterLink, CommonModule, ReactiveFormsModule, FormsModule],
  templateUrl: './send-candidature.component.html',
  styleUrl: './send-candidature.component.css'
})
export class SendCandidatureComponent implements OnInit{
  constructor(private service: RecruitingService){}

  sendCandidature(){
    const candidatura: candidature = {
      id:0,
      candidate : {
        id:0,
        firstName: this.myForm.value.firstName,
        lastName: this.myForm.value.lastName,
        email:this.myForm.value.email,
        birthdayDate:this.myForm.value.birthdayDate,
        address:this.myForm.value.address,
        telephone:this.myForm.value.telephone
      },
      description:this.myForm.value.description,
      status: "sent",
      candidatureDate:this.myForm.value.candidatureDate
    }
    this.service.findCandidate(candidatura.candidate.email).subscribe(data=>{
      console.log(data);
      
      if(data==null){
        this.service.sendCandidate(candidatura.candidate).subscribe(data=>{
          this.service.sendCandidature(candidatura).subscribe()
          this.myForm.reset()
        })
      }
    
    })

    
  }


  ngOnInit(): void {
    this.myForm=new FormGroup({
      firstName: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      lastName: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      birthdayDate: new FormControl(null, [Validators.required]),
      candidatureDate: new FormControl(null, [Validators.required]),
      address: new FormControl(null, [Validators.required]),
      telephone: new FormControl(null, [Validators.required, Validators.minLength(10)]),
      description: new FormControl(null, [Validators.required, Validators.minLength(2)])
    })
    
    
  }

  myForm!: FormGroup;
}
