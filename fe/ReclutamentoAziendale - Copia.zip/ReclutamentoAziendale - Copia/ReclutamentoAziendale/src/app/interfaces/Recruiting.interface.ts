
export interface jobOffer{
    id: number,
    agency: string,
    status: string,
    jobType:  string,
    address: string
}
export interface candidate{
    id:number,
    firstName:string,
    lastName:string,
    birthdayDate:Date,
    email:string,
    address:string,
    telephone:string
}
export interface candidature{
    id:number,
    candidate: candidate,
    description: string,
    candidatureDate:Date,
    status:string
}
export interface communication{
    id:number,
    candidate: candidate,
    jobOffer: jobOffer,
    description:string,
    data: Date
}