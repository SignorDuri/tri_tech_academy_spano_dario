import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { RecruitingService } from '../Services/recruiting.service';
import { candidate, candidature } from '../interfaces/Recruiting.interface';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-view-candidate',
  standalone: true,
  imports: [RouterLink, NgFor, CommonModule, ReactiveFormsModule, FormsModule, NgIf],
  templateUrl: './view-candidate.component.html',
  styleUrl: './view-candidate.component.css'
})
export class ViewCandidateComponent implements OnInit {


  constructor(private service:RecruitingService){}

  candidates:candidate[]=[];
  prova:boolean=true
  find:boolean=false


  findByName(){
    this.prova=false
    this.service.findCandidateByName(this.myForm.value.firstName, this.myForm.value.lastName).subscribe(data=>{
      console.log(data);
      this.myForm.reset()
        this.candidates=data;
        console.log(this.candidates);
      
        if(this.candidates.length==0){
          this.find=true
        }else{
          this.find=false
        }
        
        
    })

  }
  turnBack(){
    this.prova=true
    this.service.getCandidate().subscribe(data=>{
      this.candidates=data
    })
  }



  deleteCandidate(index:number){    
    console.log("so dentro");
    
    this.service.deleteCandidate(this.candidates[index].id).subscribe(data =>{
          this.candidates.splice(index, 1);
    })
  
}



  ngOnInit(): void {
    this.myForm=new FormGroup({
      firstName: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      lastName: new FormControl(null, [Validators.required, Validators.minLength(2)])
    })



    this.service.getCandidate().subscribe(data => {
      console.log(data)
      this.candidates=data;
    })

  
    
  }
  myForm!: FormGroup;
}
