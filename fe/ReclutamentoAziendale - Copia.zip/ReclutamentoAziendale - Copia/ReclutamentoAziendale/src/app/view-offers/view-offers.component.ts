import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { jobOffer } from '../interfaces/Recruiting.interface';
import { RecruitingService } from '../Services/recruiting.service';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-view-offers',
  standalone: true,
  imports: [NgFor, NgIf, RouterLink],
  templateUrl: './view-offers.component.html',
  styleUrl: './view-offers.component.css'
})
export class ViewOffersComponent implements OnInit{
  constructor(private service:RecruitingService){}

  jobOffers:jobOffer[]=[];

  ngOnInit(): void {
    this.service.getJobOffers().subscribe(data =>{
      this.jobOffers=data;
    })
  }

}
