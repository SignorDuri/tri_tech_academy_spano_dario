import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JobOffersDashboardComponent } from './job-offers-dashboard.component';

describe('JobOffersDashboardComponent', () => {
  let component: JobOffersDashboardComponent;
  let fixture: ComponentFixture<JobOffersDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [JobOffersDashboardComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(JobOffersDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
