import { NgFor, CommonModule, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { RecruitingService } from '../Services/recruiting.service';
import { jobOffer } from '../interfaces/Recruiting.interface';

@Component({
  selector: 'app-job-offers-dashboard',
  standalone: true,
  imports: [ NgFor, CommonModule, ReactiveFormsModule, FormsModule, NgIf, RouterLink],
  templateUrl: './job-offers-dashboard.component.html',
  styleUrl: './job-offers-dashboard.component.css'
})
export class JobOffersDashboardComponent implements OnInit{
  constructor(private service: RecruitingService){}
  prova: boolean=true

  
  find:boolean=false
  findByAgency(){
    this.prova=false
    this.service.findByAgency(this.myForm.value.agency).subscribe(data=>{
      this.jobOffers=data
      this.myForm.reset()
      if(this.jobOffers.length==0){
        this.find=true
      }else{
        this.find=false
      }
    })

  }
  turnBack(){
    this.prova=true
    this.service.getJobOffers().subscribe(data=>{
      this.jobOffers=data
    })
  }

  deleteJobOffer(index:number){    
    console.log("so dentro");
    
    this.service.deleteJobOffer(this.jobOffers[index].id).subscribe(data =>{
          this.jobOffers.splice(index, 1);
    })
  
}
  jobOffers:jobOffer[]=[];


  ngOnInit(): void {
    this.myForm=new FormGroup({
      agency: new FormControl(null, [Validators.required, Validators.minLength(2)])
    })




    this.service.getJobOffers().subscribe(data=>{
      this.jobOffers=data
      console.log(this.jobOffers);
      
    })
  }
  myForm!: FormGroup;

  
}
