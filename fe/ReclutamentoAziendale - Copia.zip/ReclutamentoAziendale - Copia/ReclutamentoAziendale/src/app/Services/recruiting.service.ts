import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { candidature, jobOffer } from '../interfaces/Recruiting.interface';
import { myPaths } from '../enums/myPaths';
import{ candidate }from '../interfaces/Recruiting.interface';

@Injectable({
  providedIn: 'root'
})
export class RecruitingService {

  constructor(private http: HttpClient) { }

  getJobOffers(): Observable<jobOffer[]>{
    return this.http.get<jobOffer[]>(`${myPaths.Home}${myPaths.JobOffers}`);
  }
  
  sendJobOffer(data:jobOffer): Observable<any>{
   
    return this.http.post<any>(`${myPaths.Home}${myPaths.addJobOffer}`, data)
  }
  getCandidate(): Observable<candidate[]>{
    return this.http.get<candidate[]>(`${myPaths.Home}${myPaths.Candidates}`);
  }
  getCandidatures(): Observable<candidature[]>{
    return this.http.get<candidature[]>(`${myPaths.Home}${myPaths.getCandidatures}`);
  }
  getChartCandidatures(): Observable<candidature[]>{
    return this.http.get<candidature[]>(`${myPaths.Home}${myPaths.getCandidatures}`);
  }
  deleteJobOffer(id:number): Observable<any>{
    return this.http.delete<any>(myPaths.Home + myPaths.deleteJobOffer +id)
  }

  findCandidate(data:string):Observable<candidate>{
    return this.http.get<candidate>( myPaths.Home + myPaths.findCandidate + data)
  }
  findCandidateByName(firstName:string, lastName:string):Observable<candidate[]>{
    return this.http.get<candidate[]>( myPaths.Home + myPaths.findCandidateByName + firstName + "&lastName="+lastName)
  }
  
  findByAgency(agency:string):Observable<jobOffer[]>{
    return this.http.get<jobOffer[]>( myPaths.Home + myPaths.findByAgency + agency)
  }
  deleteCandidate(id:number):Observable<any>{
    return this.http.delete<any>(myPaths.Home + myPaths.deleteCandidate + id)
  }

 

  sendCandidate(data:candidate):Observable<any>{
    return this.http.post<any>(`${myPaths.Home}${myPaths.addCandidate}`, data)
  }
  sendCandidature(data:candidature):Observable<any>{
    return this.http.post<any>(`${myPaths.Home}${myPaths.addCandidature}`, data)
  }
}
