export const myPaths = {
    Home:'http://localhost:8080',
    JobOffers:'/JobOffers',
    addJobOffer:'/addJobOffer',
    Candidates:'/candidates',
    addCandidate:'/addCandidate',
    addCandidature:'/addJobApplication',
    findCandidate:'/findCandidate?email=',
    findCandidateByName:'/candidates/searchByNameAndSurname?firstName=',
    deleteCandidate:'/deleteCandidate?id=',
    getCandidatures:'/jobApplications',
    deleteJobOffer:'/deleteJobOffer?id=',
    findByAgency:'/jobOffers/findByAgency?agency='
}