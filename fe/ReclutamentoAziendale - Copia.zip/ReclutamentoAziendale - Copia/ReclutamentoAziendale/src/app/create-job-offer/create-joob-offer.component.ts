import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { RecruitingService } from '../Services/recruiting.service';
import { jobOffer } from '../interfaces/Recruiting.interface';

@Component({
  selector: 'app-create-joob-offer',
  standalone: true,
  imports: [RouterLink,ReactiveFormsModule, CommonModule, FormsModule],
  templateUrl: './create-joob-offer.component.html',
  styleUrl: './create-joob-offer.component.css'

})
export class CreateJoobOfferComponent implements OnInit{

  constructor(private service:RecruitingService){}

  myForm!: FormGroup;

  jobOffer:jobOffer={id: 0, agency: "", status: "", jobType:"", address:"" }

  sendJobOffer(){
    this.jobOffer = this.myForm.value;
    this.service.sendJobOffer(this.jobOffer).subscribe();
    this.myForm.reset();
   }

   ngOnInit(): void {
    this.myForm=new FormGroup({
      agency: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      jobType: new FormControl(null, [Validators.required, Validators.minLength(2)]),
      address: new FormControl(null, [Validators.required]),
      status: new FormControl(null, [Validators.required, Validators.minLength(4)])
    })
    
    
  }

}
